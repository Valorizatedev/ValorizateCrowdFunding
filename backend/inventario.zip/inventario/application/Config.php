<?php

define('BASE_URL', 'http://localhost/inventario/');
define('DEFAULT_CONTROLLER', 'index');
define('DEFAULT_LAYOUT', '2id_v3');

define('APP_NAME', 'CRM Tecnotaxia');
define('APP_COMPANY_NAME', 'Tecnotaxia');
define('APP_COMPANY_NIT', '');
define('APP_COMPANY_WEB', 'www.tecnotaxia.com');
define('APP_LOGO', '');
define('SESSION_TIME', 100000);

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'root');
define('DB_NAME', '2iinventario');
define('DB_PORT', '5432');
define('DB_CHAR', 'utf8');


define('EMAIL_HOST', '');
define('EMAIL_REMITENTE', '');
define('EMAIL_NOMBRE_REMITENTE', '');
define('EMAIL_USER', '');
define('EMAIL_PASS', '');
define('EMAIL_ENTRADA', '');
define('EMAIL_SALIDA', '587');


date_default_timezone_set('America/Bogota');

?>