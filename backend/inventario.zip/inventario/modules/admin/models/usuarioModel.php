<?php

class usuarioModel extends Model {

    public function __construct() {
        parent::__construct();
    }

    public function consultar($condicion = '1') {
        $roles = $this->_db->query("SELECT usu_key, usu_nombre, usu_apellidos, usu_login, usu_password, usu_num_documento, 
            usu_observaciones, usu_foto, usu_email, usu_estado, tdo_key, rol_key FROM usu WHERE " . $condicion);
        if ($roles)
            return $roles->fetchall();
    }

    public function crear($datos) {
        $condicion = "tdo_key=" . $datos['tdo_key'] . " AND usu_num_documento = '" . $datos['usu_num_documento'] . "'";
        $key = $this->consultar($condicion);
        if (!$key) {
            $this->_db->prepare("INSERT INTO usu (usu_nombre, usu_apellidos, usu_login, usu_num_documento, 
                usu_observaciones, usu_foto, usu_email, usu_estado, tdo_key, rol_key) VALUES (:usu_nombre, :usu_apellidos, 
                :usu_login, :usu_num_documento, :usu_observaciones, :usu_foto, :usu_email, 1, :tdo_key, :rol_key)")
                    ->execute(
                            array(
                                ':usu_nombre' => $datos['usu_nombre'],
                                ':usu_apellidos' => $datos['usu_apellidos'],
                                ':usu_login' => $datos['usu_login'],
                                ':usu_num_documento' => $datos['usu_num_documento'],
                                ':usu_observaciones' => $datos['usu_observaciones'],
                                ':usu_foto' => $datos['usu_foto'],
                                ':usu_email' => $datos['usu_email'],
                                ':tdo_key' => $datos['tdo_key'],
                                ':rol_key' => $datos['rol_key']
                            )
            );
            $condicion = "tdo_key=" . $datos['tdo_key'] . " AND usu_num_documento = '" . $datos['usu_num_documento'] . "'";
            $key = $this->consultar($condicion);
        } else {
            $this->actualizar($key[0]['usu_key'], $datos);
        }
        return $key[0];
    }

    public function actualizar($key, $datos) {
        $this->_db->prepare("UPDATE usu SET usu_nombre = :usu_nombre, usu_apellidos = :usu_apellidos, 
            usu_num_documento = :usu_num_documento, usu_observaciones = :usu_observaciones, usu_foto = :usu_foto, 
            usu_email = :usu_email, usu_estado = 1, tdo_key = :tdo_key, rol_key = :rol_key WHERE usu_key='{$key}'")
                ->execute(
                        array(
                            ':usu_nombre' => $datos['usu_nombre'],
                            ':usu_apellidos' => $datos['usu_apellidos'],
                            ':usu_num_documento' => $datos['usu_num_documento'],
                            ':usu_observaciones' => $datos['usu_observaciones'],
                            ':usu_foto' => $datos['usu_foto'],
                            ':usu_email' => $datos['usu_email'],
                            ':tdo_key' => $datos['tdo_key'],
                            ':rol_key' => $datos['rol_key']
                        )
        );
    }

    public function actualizarPassword($usu_password, $usu_key) {
        $this->_db->prepare("UPDATE usu SET usu_password=:usu_password WHERE usu_key = :usu_key")
                ->execute(
                        array(
                            ':usu_password' => $usu_password,
                            ':usu_key' => $usu_key
        ));
    }

    public function eliminar($usu_key) {
        $this->_db->prepare("UPDATE usu SET usu_estado=0 WHERE usu_key = :usu_key")
                ->execute(
                        array(
                            ':usu_key' => $usu_key
        ));
    }

}
?>